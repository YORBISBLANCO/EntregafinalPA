package com.proaula.aula.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.proaula.aula.Entity.ContactoMensaje;

public interface ContactoMensajeRepository extends JpaRepository<ContactoMensaje, Long> {
	java.util.List<ContactoMensaje> findByNameContainingIgnoreCaseOrEmailContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrMessageContainingIgnoreCase(String name, String email, String phone, String message);
}
