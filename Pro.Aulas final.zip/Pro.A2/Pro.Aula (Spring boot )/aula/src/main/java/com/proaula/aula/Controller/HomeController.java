package com.proaula.aula.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Comparator;

import com.proaula.aula.Entity.Usuario;
import com.proaula.aula.Service.BusService;
import com.proaula.aula.Service.RutaService;
import com.proaula.aula.Service.UsuarioService;

@Controller
public class HomeController {
    @Autowired
    private BusService busService;
    @Autowired
    private RutaService rutaService;
    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping({"/inicio_de_sesion.html", "/inicio_de_sesion"})
    public String login() {
        return "inicio_de_sesion";
    }

    @GetMapping({"/rejistro_de_persona.html", "/registro"})
    public String registro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "rejistro_de_persona";
    }

    @PostMapping("/registro")
    public String registrar(@ModelAttribute Usuario usuario) {
        usuarioService.register(usuario);
        return "redirect:/inicio_de_sesion.html";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute Usuario usuario, Model model) {
        Usuario user = usuarioService.login(usuario.getUsername(), usuario.getPassword());
        if (user != null) {
            if ("ADMIN".equals(user.getRole())) {
                return "redirect:/index_2";
            } else {
                model.addAttribute("usuario", user);
                return "Usuario/index_3";
            }
        }
        model.addAttribute("error", "Credenciales inválidas");
        return "inicio_de_sesion";
    }

    @GetMapping("/index_3")
    public String index3(Model model) {
        model.addAttribute("usuario", new Usuario()); // Simula usuario logueado
        return "Usuario/index_3";
    }

    @GetMapping({"/public_index_3", "/index_3_public"})
    public String publicIndex3(Model model) {
        // Página pública: no requiere usuario autenticado
        model.addAttribute("usuario", null);
        model.addAttribute("contactoMensaje", new com.proaula.aula.Entity.ContactoMensaje());
        return "Usuario/index_3_public";
    }

    @GetMapping("/viajar")
    public String viajar(Model model) {
        model.addAttribute("usuario", new Usuario()); // Usuario autenticado
        return "Usuario/viajar";
    }

    @GetMapping("/viajar_public")
    public String viajarPublic(Model model) {
        // Página pública de viajes: sin guardar datos
        return "Usuario/viajar_public";
    }

    @PostMapping("/viajar")
    public String guardarViajeAutenticado(@ModelAttribute Usuario usuario, Model model) {
        // Aquí irá la lógica para guardar la reserva en BD
        // Por ahora solo retorna la página de confirmación
        model.addAttribute("mensaje", "Viaje reservado correctamente");
        return "Usuario/viajar";
    }


    @GetMapping("/contacto_public")
    public String contactoPublic(Model model) {
        // Contacto público: no guarda datos, solo muestra mensaje de confirmación
        model.addAttribute("mensaje", "Gracias por tu consulta. Nos pondremos en contacto pronto.");
        return "Usuario/index_3_public";
    }

    @GetMapping("/gestionar-usuarios")
    public String gestionarUsuarios(@RequestParam(value = "buscar", defaultValue = "") String buscar, Model model) {
        // Cargar todos los usuarios desde la base de datos y separarlos por rol
        List<com.proaula.aula.Entity.Usuario> todos = usuarioService.getAllUsuarios();

        // Filtrar por búsqueda si está presente
        if (buscar != null && !buscar.isEmpty()) {
            String buscarLower = buscar.toLowerCase();
            todos = todos.stream()
                    .filter(u -> (u.getNombres() != null && u.getNombres().toLowerCase().contains(buscarLower))
                            || (u.getApellidos() != null && u.getApellidos().toLowerCase().contains(buscarLower))
                            || (u.getEmail() != null && u.getEmail().toLowerCase().contains(buscarLower))
                            || (u.getUsername() != null && u.getUsername().toLowerCase().contains(buscarLower)))
                    .collect(Collectors.toList());
        }

        List<com.proaula.aula.Entity.Usuario> administradores = todos.stream()
                .filter(u -> u.getRole() != null && u.getRole().equalsIgnoreCase("ADMIN"))
                .sorted(Comparator.comparing(com.proaula.aula.Entity.Usuario::getNombres, Comparator.nullsLast(String::compareTo))
                        .thenComparing(com.proaula.aula.Entity.Usuario::getApellidos, Comparator.nullsLast(String::compareTo)))
                .collect(Collectors.toList());

        List<com.proaula.aula.Entity.Usuario> usuarios = todos.stream()
                .filter(u -> u.getRole() == null || !u.getRole().equalsIgnoreCase("ADMIN"))
                .sorted(Comparator.comparing(com.proaula.aula.Entity.Usuario::getNombres, Comparator.nullsLast(String::compareTo))
                        .thenComparing(com.proaula.aula.Entity.Usuario::getApellidos, Comparator.nullsLast(String::compareTo)))
                .collect(Collectors.toList());

        model.addAttribute("administradores", administradores);
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("buscar", buscar);
        model.addAttribute("mensaje", "Gestión de usuarios");
        return "Admin/gestionar_usuarios";
    }

    @GetMapping("/editar-usuario/{id}")
    public String editarUsuario(@PathVariable Long id, Model model) {
        com.proaula.aula.Entity.Usuario usuario = usuarioService.getUsuarioById(id);
        if (usuario == null) {
            return "redirect:/gestionar-usuarios";
        }
        model.addAttribute("usuario", usuario);
        return "Admin/editar_usuario";
    }

    @GetMapping("/eliminar-usuario/{id}")
    public String eliminarUsuario(@PathVariable Long id, org.springframework.web.servlet.mvc.support.RedirectAttributes redirectAttrs) {
        com.proaula.aula.Entity.Usuario u = usuarioService.getUsuarioById(id);
        if (u != null) {
            usuarioService.deleteById(id);
            redirectAttrs.addFlashAttribute("mensaje", "Usuario eliminado correctamente.");
        } else {
            redirectAttrs.addFlashAttribute("mensaje", "Usuario no encontrado.");
        }
        return "redirect:/gestionar-usuarios";
    }

    @PostMapping("/actualizar-usuario")
    public String actualizarUsuario(@ModelAttribute com.proaula.aula.Entity.Usuario usuario) {
        // Mantener contraseña actual si el administrador no ingresó nueva
        com.proaula.aula.Entity.Usuario existente = usuarioService.getUsuarioById(usuario.getId());
        if (existente != null) {
            if (usuario.getPassword() == null || usuario.getPassword().isEmpty()) {
                usuario.setPassword(existente.getPassword());
            }
        }
        usuarioService.register(usuario);
        return "redirect:/gestionar-usuarios";
    }

    @PostMapping("/admin-crear-usuario")
    public String crearUsuario(@ModelAttribute Usuario usuario) {
        usuarioService.register(usuario);
        return "redirect:/gestionar-usuarios";
    }

    @PostMapping("/admin-login")
    public String adminLogin(String adminCode) {
        // 📝 CÓDIGO ADMIN: Cambia aquí el código que desees
        // Ejemplo actual: ADMIN2025
        if ("ADMIN2025".equals(adminCode)) {
            return "redirect:/index_2";
        }
        return "redirect:/?error=invalid_code";
    }

    @GetMapping("/reportes")
    public String reportes(@RequestParam(value = "buscar", defaultValue = "") String buscar, Model model) {
        List<com.proaula.aula.Entity.Bus> buses = busService.getAllBuses();
        
        // Filtrar por búsqueda si está presente
        if (buscar != null && !buscar.isEmpty()) {
            String buscarLower = buscar.toLowerCase();
            buses = buses.stream()
                    .filter(b -> (b.getPlaca() != null && b.getPlaca().toLowerCase().contains(buscarLower))
                            || (b.getModelo() != null && b.getModelo().toLowerCase().contains(buscarLower)))
                    .collect(Collectors.toList());
        }
        
        model.addAttribute("totalBuses", busService.getAllBuses().size());
        model.addAttribute("buses", buses);
        model.addAttribute("totalRutas", rutaService.getAllRutas().size());
        model.addAttribute("totalUsuarios", usuarioService.getAllUsuarios().size());
        model.addAttribute("usuariosActivos", usuarioService.getAllUsuarios().size());
        model.addAttribute("buscar", buscar);
        return "Admin/reportes";
    }

    @GetMapping("/consultas")
    public String consultas(Model model) {
        model.addAttribute("buses", busService.getAllBuses());
        return "Usuario/consultas";
    }

    @GetMapping("/index_2")
    public String index2() {
        return "Admin/index2";
    }

    @GetMapping("/privacidad")
    public String privacidad() {
        return "privacidad";
    }

    @GetMapping("/terminos")
    public String terminos() {
        return "terminos";
    }
}