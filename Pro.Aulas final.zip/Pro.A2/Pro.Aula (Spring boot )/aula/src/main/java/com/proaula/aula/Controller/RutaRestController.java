package com.proaula.aula.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proaula.aula.Entity.Ruta;
import com.proaula.aula.Service.RutaService;

@RestController
@RequestMapping("/api/rutas")
public class RutaRestController {
    @Autowired
    private RutaService rutaService;

    @GetMapping
    public List<Ruta> getAllRutas() {
        return rutaService.getAllRutas();
    }

    @GetMapping("/{id}")
    public Ruta getRutaById(@PathVariable Long id) {
        return rutaService.getRutaById(id);
    }

    @PostMapping
    public Ruta createRuta(@RequestBody Ruta ruta) {
        return rutaService.saveRuta(ruta);
    }

    @PutMapping("/{id}")
    public Ruta updateRuta(@PathVariable Long id, @RequestBody Ruta ruta) {
        ruta.setId(id);
        return rutaService.saveRuta(ruta);
    }

    @DeleteMapping("/{id}")
    public void deleteRuta(@PathVariable Long id) {
        rutaService.deleteRuta(id);
    }
}