package com.proaula.aula.Service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import com.github.javafaker.Faker;
import com.proaula.aula.Barrios.Localidades;
import com.proaula.aula.Entity.Bus;
import com.proaula.aula.Entity.Parada;
import com.proaula.aula.Entity.Ruta;
import com.proaula.aula.Entity.Usuario;
import com.proaula.aula.Repository.BusRepository;
import com.proaula.aula.Repository.ParadaRepository;
import com.proaula.aula.Repository.RutaRepository;
import com.proaula.aula.Repository.UsuarioRepository;

@Service
public class DataSeederService implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeederService.class);
    @Autowired
    private BusRepository busRepository;
    @Autowired
    private RutaRepository rutaRepository;
    @Autowired
    private ParadaRepository paradaRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    private Faker faker = new Faker();
    private Random random = new Random();

    @Override
    public void run(String... args) throws Exception {
        try {
            // Verificar si ya existen datos para evitar duplicados
            if (rutaRepository.count() > 0) {
                log.info("Data already present, skipping seeding.");
                return;
            }

            List<String> allBarrios = Localidades.obtenerTodosLosBarrios();

            // Reduce initial dataset for faster, more stable startup in development
            int rutasToCreate = 20;
            int busesToCreate = 50;
            int usuariosToCreate = 100;

            // Insertar rutas con barrios y paradas
            List<Ruta> rutas = new ArrayList<>();
            for (int i = 0; i < rutasToCreate; i++) {
                Ruta ruta = new Ruta();
                ruta.setNombre(faker.address().city() + " Route " + (i + 1));
                ruta.setHoraAproximada(LocalTime.of(random.nextInt(24), random.nextInt(60)));
                // Asignar 3-5 barrios aleatorios de Localidades
                List<String> barriosRuta = new ArrayList<>();
                for (int j = 0; j < random.nextInt(3) + 3; j++) {
                    barriosRuta.add(allBarrios.get(random.nextInt(allBarrios.size())));
                }
                ruta.setBarrios(barriosRuta);
                ruta.setParadas(new ArrayList<>());
                // Agregar paradas
                for (int j = 0; j < Math.max(2, random.nextInt(3) + 2); j++) {
                    Parada parada = new Parada();
                    parada.setNombre(faker.address().streetName());
                    parada.setUbicacion(faker.address().fullAddress());
                    parada.setRuta(ruta);
                    ruta.getParadas().add(parada);
                }
                rutas.add(rutaRepository.save(ruta));
            }

            // Insertar buses
            for (int i = 0; i < busesToCreate; i++) {
                Bus bus = new Bus();
                bus.setPlaca(faker.bothify("???-###"));
                bus.setModelo("Modelo " + faker.number().numberBetween(1, 100));
                bus.setColor(faker.color().name());
                bus.setConductor(faker.name().fullName());
                bus.setRuta(rutas.get(random.nextInt(rutas.size())));
                busRepository.save(bus);
            }

            // Insertar usuarios (combinación de USER y ADMIN)
            for (int i = 0; i < usuariosToCreate; i++) {
                Usuario usuario = new Usuario();
                usuario.setUsername(faker.internet().emailAddress());
                usuario.setPassword("password123");
                // Aproximadamente 80% USER y 20% ADMIN
                usuario.setRole(random.nextInt(100) < 80 ? "USER" : "ADMIN");
                usuario.setNombres(faker.name().firstName());
                usuario.setApellidos(faker.name().lastName());
                usuario.setEmail(faker.internet().emailAddress());
                usuarioRepository.save(usuario);
            }
            log.info("Data seeding completed: {} rutas, {} buses, {} usuarios.", rutasToCreate, busesToCreate, usuariosToCreate);
        } catch (Exception ex) {
            // Catch any exception to prevent crash during startup; log for later inspection
            log.error("Error during data seeding, continuing without seeding: {}", ex.getMessage(), ex);
        }
    }
}